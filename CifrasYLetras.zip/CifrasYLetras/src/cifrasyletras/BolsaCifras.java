/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cifrasyletras;

import java.util.Random;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
/**
 *
 * @author isa
 */
public class BolsaCifras {
    
    private int c1, c2, c3, c4, c5, c6, c7, c8, c9, c10, c11, c12, c13, c14, c15, c16, c17, c18, c19, c20, c21, c22, c23, c24;
    private int totalCifras = 0;
    private Random random;
    
    public BolsaCifras(){
        random = new Random();
        leerFichero();
    }
    
    private void leerFichero(){
        try{
            BufferedReader br = new BufferedReader(new FileReader("src/cifrasyletras/Data/Cifras.txt"));
            String linea = br.readLine();
            br.close();
            
            char[] datos = linea.toCharArray();
            
            int i = 1;
            int numero = 0;
            int posicion = 0;
            
            while (posicion < datos.length){
                char ch = datos[posicion];
                if (ch >= '0' && ch <= '9'){
                    numero = numero*10 + (ch-'0');
                }else if(ch == ' '){
                    guardarCifra(i, numero);
                    i++;
                    numero = 0;
                }
                posicion++;
            }
            
            guardarCifra(i, numero);
            totalCifras = i;
        } catch(IOException e){
            System.out.println("Error de lectura.");
        }
    }
    
    private void guardarCifra(int index, int numero){
        if(index == 1) c1 = numero;
        else if(index == 2) c2 = numero;
        else if(index == 3) c3 = numero;
        else if(index == 4) c4 = numero;
        else if(index == 5) c5 = numero;
        else if(index == 6) c6 = numero;
        else if(index == 7) c7 = numero;
        else if(index == 8) c8 = numero;
        else if(index == 9) c9 = numero;
        else if(index == 10) c10 = numero;
        else if(index == 11) c11 = numero;
        else if(index == 12) c12 = numero;
        else if(index == 13) c13 = numero;
        else if(index == 14) c14 = numero;
        else if(index == 15) c15 = numero;
        else if(index == 16) c16 = numero;
        else if(index == 17) c17 = numero;
        else if(index == 18) c18 = numero;
        else if(index == 19) c19 = numero;
        else if(index == 20) c20 = numero;
        else if(index == 21) c21 = numero;
        else if(index == 22) c22 = numero;
        else if(index == 23) c23 = numero;
        else if(index == 24) c24 = numero;
    }
    
    public int extraerCifra(){
        int op = 1 + random.nextInt(totalCifras);
        int numero = c1;
        if(op==1) numero = c1;if(op==2) numero = c2;if(op==3) numero = c3;if(op==4) numero = c4;if(op==5) numero = c5;if(op==6) numero = c6;
        if(op==7) numero = c7;if(op==8) numero = c8;if(op==9) numero = c9;if(op==10) numero = c10;if(op==11) numero = c11;if(op==12) numero = c12;
        if(op==13) numero = c13;if(op==14) numero = c14;if(op==15) numero = c15;if(op==16) numero = c16;if(op==17) numero = c17;if(op==18) numero = c18;
        if(op==19) numero = c19;if(op==20) numero = c20;if(op==21) numero = c21;if(op==22) numero = c22;if(op==23) numero = c23;if(op==24) numero = c24;
        
        return numero;
    }
    
}
